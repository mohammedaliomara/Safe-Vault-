using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;
using SafeVault.Data;
using SafeVault.DTOs;
using SafeVault.Models;
using SafeVault.Services;
using Xunit;

namespace SafeVault.Tests;

/// <summary>
/// Tests for Activity 2 – Authentication and RBAC.
/// Uses an in-memory SQLite database so no real file is needed.
/// </summary>
public class AuthServiceTests : IDisposable
{
    private readonly AppDbContext            _db;
    private readonly IInputValidationService _validator;
    private readonly IAuthService            _sut;

    public AuthServiceTests()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        _db        = new AppDbContext(options);
        _validator = new InputValidationService();
        _sut       = new AuthService(_db, _validator);
    }

    // ── Registration tests ────────────────────────────────────────────────────

    [Fact]
    public async Task Register_ValidUser_ShouldSucceed()
    {
        var request = new RegisterRequest
        {
            Username = "alice",
            Password = "Str0ng!Pass",
            Email    = "alice@example.com",
            Role     = UserRole.Viewer
        };

        var (success, error, user) = await _sut.RegisterAsync(request);

        success.Should().BeTrue();
        error.Should().BeEmpty();
        user.Should().NotBeNull();
        user!.Username.Should().Be("alice");
    }

    [Fact]
    public async Task Register_DuplicateUsername_ShouldFail()
    {
        var request = new RegisterRequest
        {
            Username = "alice",
            Password = "Str0ng!Pass",
            Email    = "alice@example.com"
        };

        await _sut.RegisterAsync(request);

        var (success, error, _) = await _sut.RegisterAsync(new RegisterRequest
        {
            Username = "alice",
            Password = "Str0ng!Pass",
            Email    = "different@example.com"
        });

        success.Should().BeFalse();
        error.Should().Contain("already registered");
    }

    [Fact]
    public async Task Register_WeakPassword_ShouldFail()
    {
        var request = new RegisterRequest
        {
            Username = "bob",
            Password = "weak",
            Email    = "bob@example.com"
        };

        var (success, error, _) = await _sut.RegisterAsync(request);

        success.Should().BeFalse();
        error.Should().NotBeEmpty();
    }

    [Fact]
    public async Task Register_PasswordIsHashed_NeverStoredPlain()
    {
        var plainPassword = "Str0ng!Pass";
        var request = new RegisterRequest
        {
            Username = "carol",
            Password = plainPassword,
            Email    = "carol@example.com"
        };

        var (_, _, user) = await _sut.RegisterAsync(request);

        var dbUser = await _db.Users.FirstAsync(u => u.Username == "carol");

        // Stored hash must NOT equal the plain-text password
        dbUser.PasswordHash.Should().NotBe(plainPassword);
        // BCrypt hashes start with "$2"
        dbUser.PasswordHash.Should().StartWith("$2");
    }

    // ── Login tests ───────────────────────────────────────────────────────────

    [Fact]
    public async Task Login_ValidCredentials_ShouldSucceed()
    {
        await _sut.RegisterAsync(new RegisterRequest
        {
            Username = "dave",
            Password = "Str0ng!Pass",
            Email    = "dave@example.com"
        });

        var (success, error, user) = await _sut.LoginAsync(new LoginRequest
        {
            Username = "dave",
            Password = "Str0ng!Pass"
        });

        success.Should().BeTrue();
        error.Should().BeEmpty();
        user!.Username.Should().Be("dave");
    }

    [Fact]
    public async Task Login_WrongPassword_ShouldFail()
    {
        await _sut.RegisterAsync(new RegisterRequest
        {
            Username = "eve",
            Password = "Str0ng!Pass",
            Email    = "eve@example.com"
        });

        var (success, error, _) = await _sut.LoginAsync(new LoginRequest
        {
            Username = "eve",
            Password = "WrongPass!"
        });

        success.Should().BeFalse();
        error.Should().Be("Invalid credentials.");
    }

    [Fact]
    public async Task Login_NonExistentUser_ReturnsGenericError()
    {
        var (success, error, _) = await _sut.LoginAsync(new LoginRequest
        {
            Username = "ghost",
            Password = "Str0ng!Pass"
        });

        success.Should().BeFalse();
        // Must NOT say "user not found" — generic message prevents enumeration
        error.Should().Be("Invalid credentials.");
    }

    // ── RBAC / Role management tests ──────────────────────────────────────────

    [Fact]
    public async Task UpdateRole_AdminCanElevateUser_ShouldSucceed()
    {
        // Seed an admin
        var adminUser = new User
        {
            Username     = "admin",
            Email        = "admin@example.com",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin@12345"),
            Role         = UserRole.Admin,
            IsActive     = true
        };
        _db.Users.Add(adminUser);
        await _db.SaveChangesAsync();

        // Seed a viewer
        var (_, _, viewer) = await _sut.RegisterAsync(new RegisterRequest
        {
            Username = "viewer1",
            Password = "Str0ng!Pass",
            Email    = "viewer1@example.com",
            Role     = UserRole.Viewer
        });

        var (success, error) =
            await _sut.UpdateUserRoleAsync(viewer!.Id, UserRole.Editor, adminUser.Id);

        success.Should().BeTrue();
        error.Should().BeEmpty();

        var updated = await _db.Users.FindAsync(viewer.Id);
        updated!.Role.Should().Be(UserRole.Editor);
    }

    [Fact]
    public async Task UpdateRole_AdminCannotChangeSelf_ShouldFail()
    {
        var adminUser = new User
        {
            Username     = "selfadmin",
            Email        = "selfadmin@example.com",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin@12345"),
            Role         = UserRole.Admin,
            IsActive     = true
        };
        _db.Users.Add(adminUser);
        await _db.SaveChangesAsync();

        var (success, error) =
            await _sut.UpdateUserRoleAsync(adminUser.Id, UserRole.Viewer, adminUser.Id);

        success.Should().BeFalse();
        error.Should().Contain("own role");
    }

    public void Dispose() => _db.Dispose();
}
