using FluentAssertions;
using SafeVault.Services;
using Xunit;

namespace SafeVault.Tests;

/// <summary>
/// Tests for Activity 1 – Input Validation and SQL Injection Prevention.
/// Each test verifies that the InputValidationService correctly accepts
/// safe inputs and rejects dangerous ones.
/// </summary>
public class InputValidationTests
{
    private readonly IInputValidationService _sut = new InputValidationService();

    // ── Username validation ───────────────────────────────────────────────────

    [Theory]
    [InlineData("alice")]
    [InlineData("bob123")]
    [InlineData("user_name")]
    [InlineData("user-name")]
    [InlineData("user.name")]
    public void ValidUsername_ShouldReturnTrue(string username)
    {
        _sut.IsValidUsername(username).Should().BeTrue();
    }

    [Theory]
    [InlineData("")]                  // Empty
    [InlineData("  ")]                // Whitespace
    [InlineData("ab")]                // Too short (< 3)
    [InlineData("a' OR '1'='1")]      // SQL injection attempt
    [InlineData("user<script>")]      // XSS attempt
    [InlineData("user name")]         // Space not allowed
    [InlineData("thisusernameiswaytoolongandexceedsfiftycharacterslimit")]
    public void InvalidUsername_ShouldReturnFalse(string username)
    {
        _sut.IsValidUsername(username).Should().BeFalse();
    }

    // ── Email validation ──────────────────────────────────────────────────────

    [Theory]
    [InlineData("alice@example.com")]
    [InlineData("user.name+tag@company.org")]
    public void ValidEmail_ShouldReturnTrue(string email)
    {
        _sut.IsValidEmail(email).Should().BeTrue();
    }

    [Theory]
    [InlineData("")]
    [InlineData("notanemail")]
    [InlineData("missing@domain")]
    [InlineData("@nodomain.com")]
    public void InvalidEmail_ShouldReturnFalse(string email)
    {
        _sut.IsValidEmail(email).Should().BeFalse();
    }

    // ── Password validation ───────────────────────────────────────────────────

    [Theory]
    [InlineData("Str0ng!Pass")]
    [InlineData("MyP@ssw0rd")]
    [InlineData("C0mpl3x#Word")]
    public void ValidPassword_ShouldReturnTrue(string password)
    {
        _sut.IsValidPassword(password).Should().BeTrue();
    }

    [Theory]
    [InlineData("short1!")]       // Too short
    [InlineData("alllowercase1!")] // No uppercase
    [InlineData("ALLUPPERCASE1!")] // No lowercase
    [InlineData("NoSpecial123")]   // No special character
    [InlineData("NoNumbers!Abc")]  // No digit
    public void InvalidPassword_ShouldReturnFalse(string password)
    {
        _sut.IsValidPassword(password).Should().BeFalse();
    }

    // ── SQL injection detection ───────────────────────────────────────────────

    [Theory]
    [InlineData("'; DROP TABLE Users; --")]
    [InlineData("1 OR 1=1")]
    [InlineData("admin'--")]
    [InlineData("UNION SELECT * FROM users")]
    [InlineData("exec(xp_cmdshell('dir'))")]
    public void SqlInjectionPatterns_ShouldBeDetected(string input)
    {
        _sut.ContainsSqlInjectionPatterns(input).Should().BeTrue();
    }

    [Theory]
    [InlineData("hello world")]
    [InlineData("normal user input")]
    [InlineData("alice@example.com")]
    public void SafeInputs_ShouldNotTriggerSqlDetection(string input)
    {
        _sut.ContainsSqlInjectionPatterns(input).Should().BeFalse();
    }

    // ── XSS sanitisation ─────────────────────────────────────────────────────

    [Fact]
    public void ScriptTag_ShouldBeRemovedBySanitizer()
    {
        var malicious = "<script>alert('xss')</script>Hello";
        var result    = _sut.SanitizeHtml(malicious);

        result.Should().NotContain("<script>");
        result.Should().Contain("Hello");
    }

    [Fact]
    public void JavascriptEvent_ShouldBeStrippedBySanitizer()
    {
        var malicious = "<img src='x' onerror='alert(1)' />";
        var result    = _sut.SanitizeHtml(malicious);

        result.Should().NotContain("onerror");
    }

    [Fact]
    public void SafeHtmlTags_ShouldBePreserved()
    {
        var safe   = "<b>Bold</b> and <i>italic</i>";
        var result = _sut.SanitizeHtml(safe);

        result.Should().Contain("<b>Bold</b>");
        result.Should().Contain("<i>italic</i>");
    }

    [Fact]
    public void EmptyInput_ShouldReturnEmpty()
    {
        _sut.SanitizeHtml(string.Empty).Should().BeEmpty();
    }
}
