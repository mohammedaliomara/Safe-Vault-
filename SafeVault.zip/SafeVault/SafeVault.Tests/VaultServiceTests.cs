using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using SafeVault.Data;
using SafeVault.DTOs;
using SafeVault.Models;
using SafeVault.Services;
using Xunit;

namespace SafeVault.Tests;

/// <summary>
/// Tests for VaultService:
///   • XSS content sanitisation (Activity 3 fix)
///   • RBAC ownership rules (Activity 2)
///   • Parameterised query behavior via in-memory DB (Activity 1)
/// </summary>
public class VaultServiceTests : IDisposable
{
    private readonly AppDbContext  _db;
    private readonly IVaultService _sut;

    // Two test users seeded before each test
    private readonly User _admin;
    private readonly User _viewer;

    public VaultServiceTests()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        _db = new AppDbContext(options);

        _admin = new User
        {
            Id           = 1,
            Username     = "admin",
            Email        = "admin@test.com",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin@12345"),
            Role         = UserRole.Admin,
            IsActive     = true
        };

        _viewer = new User
        {
            Id           = 2,
            Username     = "viewer",
            Email        = "viewer@test.com",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("Viewer@12345"),
            Role         = UserRole.Viewer,
            IsActive     = true
        };

        _db.Users.AddRange(_admin, _viewer);
        _db.SaveChanges();

        IInputValidationService validator = new InputValidationService();
        _sut = new VaultService(_db, validator);
    }

    // ── XSS sanitisation ──────────────────────────────────────────────────────

    [Fact]
    public async Task Create_ScriptInTitle_ShouldBeStripped()
    {
        var request = new CreateVaultItemRequest
        {
            Title   = "<script>alert('xss')</script>My Note",
            Content = "Safe content"
        };

        var item = await _sut.CreateAsync(request, _admin.Id);

        item.Title.Should().NotContain("<script>");
        item.Title.Should().Contain("My Note");
    }

    [Fact]
    public async Task Create_JavascriptEventInContent_ShouldBeStripped()
    {
        var request = new CreateVaultItemRequest
        {
            Title   = "Normal Title",
            Content = "<img src='x' onerror='stealCookies()'>Important note"
        };

        var item = await _sut.CreateAsync(request, _admin.Id);

        item.Content.Should().NotContain("onerror");
        item.Content.Should().Contain("Important note");
    }

    // ── RBAC ownership ────────────────────────────────────────────────────────

    [Fact]
    public async Task GetAll_Viewer_ShouldOnlySeeOwnItems()
    {
        // Admin creates an item
        await _sut.CreateAsync(new CreateVaultItemRequest
        {
            Title   = "Admin Secret",
            Content = "Top secret"
        }, _admin.Id);

        // Viewer creates an item
        await _sut.CreateAsync(new CreateVaultItemRequest
        {
            Title   = "Viewer Note",
            Content = "My note"
        }, _viewer.Id);

        var items = (await _sut.GetAllAsync(_viewer.Id, UserRole.Viewer)).ToList();

        items.Should().HaveCount(1);
        items[0].Title.Should().Be("Viewer Note");
    }

    [Fact]
    public async Task GetAll_Admin_ShouldSeeAllItems()
    {
        await _sut.CreateAsync(new CreateVaultItemRequest
        {
            Title   = "Admin Secret",
            Content = "Top secret"
        }, _admin.Id);

        await _sut.CreateAsync(new CreateVaultItemRequest
        {
            Title   = "Viewer Note",
            Content = "My note"
        }, _viewer.Id);

        var items = (await _sut.GetAllAsync(_admin.Id, UserRole.Admin)).ToList();

        items.Should().HaveCount(2);
    }

    [Fact]
    public async Task GetById_Viewer_CannotAccessOtherUsersItem()
    {
        var adminItem = await _sut.CreateAsync(new CreateVaultItemRequest
        {
            Title   = "Admin Secret",
            Content = "Very secret"
        }, _admin.Id);

        // Viewer tries to access admin's item — should get null (404)
        var result = await _sut.GetByIdAsync(adminItem.Id, _viewer.Id, UserRole.Viewer);

        result.Should().BeNull();
    }

    [Fact]
    public async Task Delete_Viewer_CannotDeleteOtherUsersItem()
    {
        var adminItem = await _sut.CreateAsync(new CreateVaultItemRequest
        {
            Title   = "Admin Item",
            Content = "Do not delete"
        }, _admin.Id);

        var deleted = await _sut.DeleteAsync(adminItem.Id, _viewer.Id, UserRole.Viewer);

        deleted.Should().BeFalse();
        // Item still exists in the DB
        var stillExists = await _db.VaultItems.FindAsync(adminItem.Id);
        stillExists.Should().NotBeNull();
    }

    [Fact]
    public async Task Delete_Owner_CanDeleteOwnItem()
    {
        var viewerItem = await _sut.CreateAsync(new CreateVaultItemRequest
        {
            Title   = "Viewer Item",
            Content = "Delete me"
        }, _viewer.Id);

        var deleted = await _sut.DeleteAsync(viewerItem.Id, _viewer.Id, UserRole.Viewer);

        deleted.Should().BeTrue();
    }

    public void Dispose() => _db.Dispose();
}
