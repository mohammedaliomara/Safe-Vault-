using System.Text;
using Microsoft.IO;

namespace SafeVault.Middleware;

/// <summary>
/// Anti-XSS middleware that inspects every incoming request body and
/// rejects payloads that contain raw script tags.
///
/// This is a defence-in-depth layer on top of HtmlSanitizer in the service layer.
/// Activity 3 — Debugging and resolving XSS vulnerability.
/// </summary>
public class AntiXssMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<AntiXssMiddleware> _logger;

    // Patterns that indicate a script-injection attempt
    private static readonly string[] DangerousPatterns =
    [
        "<script",
        "</script>",
        "javascript:",
        "onerror=",
        "onload=",
        "onclick=",
        "onmouseover=",
        "eval(",
        "document.cookie",
        "window.location"
    ];

    public AntiXssMiddleware(RequestDelegate next, ILogger<AntiXssMiddleware> logger)
    {
        _next   = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        if (context.Request.ContentLength > 0 &&
            context.Request.ContentType?.Contains("application/json") == true)
        {
            context.Request.EnableBuffering();

            using var reader = new StreamReader(
                context.Request.Body,
                Encoding.UTF8,
                leaveOpen: true);

            var body = await reader.ReadToEndAsync();
            context.Request.Body.Position = 0;

            var lowerBody = body.ToLowerInvariant();
            foreach (var pattern in DangerousPatterns)
            {
                if (lowerBody.Contains(pattern))
                {
                    _logger.LogWarning(
                        "Blocked XSS attempt from {IP}: pattern '{Pattern}' found.",
                        context.Connection.RemoteIpAddress,
                        pattern);

                    context.Response.StatusCode  = StatusCodes.Status400BadRequest;
                    context.Response.ContentType = "application/json";
                    await context.Response.WriteAsync(
                        "{\"error\":\"Request contains disallowed content.\"}");
                    return;
                }
            }
        }

        // Add security headers to every response
        context.Response.Headers.Append("X-Content-Type-Options", "nosniff");
        context.Response.Headers.Append("X-Frame-Options",        "DENY");
        context.Response.Headers.Append("X-XSS-Protection",       "1; mode=block");
        context.Response.Headers.Append("Referrer-Policy",        "strict-origin-when-cross-origin");
        context.Response.Headers.Append(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self'; style-src 'self'");

        await _next(context);
    }
}
