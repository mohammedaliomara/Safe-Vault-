namespace SafeVault.Models;

/// <summary>
/// A piece of sensitive data stored in the vault.
/// Access is gated by the owner's role via RBAC policies.
/// </summary>
public class VaultItem
{
    public int Id { get; set; }

    // Title is sanitized against XSS before persistence
    public string Title { get; set; } = string.Empty;

    // Content is sanitized against XSS before persistence
    public string Content { get; set; } = string.Empty;

    public int OwnerId { get; set; }

    public User? Owner { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}
