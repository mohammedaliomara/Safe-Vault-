namespace SafeVault.Models;

/// <summary>
/// User entity stored in the database.
/// Passwords are NEVER stored in plain text — always BCrypt hashed.
/// </summary>
public class User
{
    public int Id { get; set; }

    // Input validation: Username is trimmed and length-constrained in the service layer
    public string Username { get; set; } = string.Empty;

    // BCrypt hash — never the raw password
    public string PasswordHash { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;

    // Role-Based Access Control (RBAC)
    public UserRole Role { get; set; } = UserRole.Viewer;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public bool IsActive { get; set; } = true;
}

/// <summary>
/// RBAC roles in ascending privilege order.
/// </summary>
public enum UserRole
{
    Viewer = 0,   // Read-only access
    Editor = 1,   // Can create/edit data
    Admin  = 2    // Full access including user management
}
