using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using SafeVault.Models;

namespace SafeVault.Services;

/// <summary>
/// Generates and validates JWT tokens.
/// Activity 2 – Authentication mechanism.
/// </summary>
public interface ITokenService
{
    string GenerateToken(User user);
    ClaimsPrincipal? ValidateToken(string token);
}

public class TokenService : ITokenService
{
    private readonly IConfiguration _config;

    public TokenService(IConfiguration config)
    {
        _config = config;
    }

    /// <summary>
    /// Creates a signed JWT that encodes the user's ID, username, email, and role.
    /// Role is embedded as a Claim so ASP.NET Core's [Authorize(Roles = "...")] works
    /// without a DB hit on every request — satisfies Activity 2 RBAC requirement.
    /// </summary>
    public string GenerateToken(User user)
    {
        var key     = new SymmetricSecurityKey(
                          Encoding.UTF8.GetBytes(_config["Jwt:Key"]!));
        var creds   = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var expires = DateTime.UtcNow.AddHours(
                          double.Parse(_config["Jwt:ExpiryHours"] ?? "8"));

        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub,   user.Id.ToString()),
            new Claim(JwtRegisteredClaimNames.Jti,   Guid.NewGuid().ToString()),
            new Claim(ClaimTypes.Name,               user.Username),
            new Claim(ClaimTypes.Email,              user.Email),
            // This claim drives [Authorize(Roles = "Admin")] etc.
            new Claim(ClaimTypes.Role,               user.Role.ToString()),
            new Claim("userId",                      user.Id.ToString())
        };

        var token = new JwtSecurityToken(
            issuer:   _config["Jwt:Issuer"],
            audience: _config["Jwt:Audience"],
            claims:   claims,
            expires:  expires,
            signingCredentials: creds
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    /// <summary>Validates a token and returns its claims; returns null if invalid.</summary>
    public ClaimsPrincipal? ValidateToken(string token)
    {
        var handler = new JwtSecurityTokenHandler();
        var key     = Encoding.UTF8.GetBytes(_config["Jwt:Key"]!);

        try
        {
            return handler.ValidateToken(token,
                new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey         = new SymmetricSecurityKey(key),
                    ValidateIssuer           = true,
                    ValidIssuer              = _config["Jwt:Issuer"],
                    ValidateAudience         = true,
                    ValidAudience            = _config["Jwt:Audience"],
                    ClockSkew                = TimeSpan.Zero   // No tolerance window
                },
                out _);
        }
        catch
        {
            return null;
        }
    }
}
