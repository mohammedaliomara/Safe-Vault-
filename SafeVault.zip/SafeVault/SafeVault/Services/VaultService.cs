using Microsoft.EntityFrameworkCore;
using SafeVault.Data;
using SafeVault.DTOs;
using SafeVault.Models;

namespace SafeVault.Services;

/// <summary>
/// CRUD operations for vault items.
/// Security highlights:
///   • All queries use EF Core parameterisation (SQL injection prevention).
///   • User-supplied HTML is sanitised before persistence (XSS prevention).
///   • Viewers can only read their own items; Admins can read all (RBAC).
/// </summary>
public interface IVaultService
{
    Task<VaultItemResponse> CreateAsync(CreateVaultItemRequest request, int ownerId);
    Task<IEnumerable<VaultItemResponse>> GetAllAsync(int requestingUserId, UserRole requestingRole);
    Task<VaultItemResponse?> GetByIdAsync(int id, int requestingUserId, UserRole requestingRole);
    Task<bool> DeleteAsync(int id, int requestingUserId, UserRole requestingRole);
}

public class VaultService : IVaultService
{
    private readonly AppDbContext            _db;
    private readonly IInputValidationService _validator;

    public VaultService(AppDbContext db, IInputValidationService validator)
    {
        _db        = db;
        _validator = validator;
    }

    public async Task<VaultItemResponse> CreateAsync(
        CreateVaultItemRequest request, int ownerId)
    {
        // Sanitise HTML in title and content to prevent Stored XSS (Activity 3)
        var sanitizedTitle   = _validator.SanitizeHtml(request.Title.Trim());
        var sanitizedContent = _validator.SanitizeHtml(request.Content);

        var item = new VaultItem
        {
            Title     = sanitizedTitle,
            Content   = sanitizedContent,
            OwnerId   = ownerId,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        _db.VaultItems.Add(item);
        await _db.SaveChangesAsync();

        // Reload with owner for the response projection
        await _db.Entry(item).Reference(i => i.Owner).LoadAsync();
        return Project(item);
    }

    public async Task<IEnumerable<VaultItemResponse>> GetAllAsync(
        int requestingUserId, UserRole requestingRole)
    {
        // RBAC: Admins see everything; Viewers/Editors see only their own items
        var query = _db.VaultItems.Include(v => v.Owner).AsQueryable();

        if (requestingRole != UserRole.Admin)
            query = query.Where(v => v.OwnerId == requestingUserId); // Parameterised

        var items = await query.OrderByDescending(v => v.CreatedAt).ToListAsync();
        return items.Select(Project);
    }

    public async Task<VaultItemResponse?> GetByIdAsync(
        int id, int requestingUserId, UserRole requestingRole)
    {
        // Parameterised query — EF Core handles the WHERE id = @id internally
        var item = await _db.VaultItems
            .Include(v => v.Owner)
            .FirstOrDefaultAsync(v => v.Id == id);

        if (item is null) return null;

        // RBAC ownership check
        if (requestingRole != UserRole.Admin && item.OwnerId != requestingUserId)
            return null; // Return null so controller sends 404 (no info leakage)

        return Project(item);
    }

    public async Task<bool> DeleteAsync(
        int id, int requestingUserId, UserRole requestingRole)
    {
        var item = await _db.VaultItems.FindAsync(id);
        if (item is null) return false;

        if (requestingRole != UserRole.Admin && item.OwnerId != requestingUserId)
            return false;

        _db.VaultItems.Remove(item);
        await _db.SaveChangesAsync();
        return true;
    }

    // ── Projection helper ────────────────────────────────────────────────────

    private static VaultItemResponse Project(VaultItem v) => new()
    {
        Id            = v.Id,
        Title         = v.Title,
        Content       = v.Content,
        OwnerUsername = v.Owner?.Username ?? "Unknown",
        CreatedAt     = v.CreatedAt,
        UpdatedAt     = v.UpdatedAt
    };
}
