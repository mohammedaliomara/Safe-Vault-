using Microsoft.EntityFrameworkCore;
using SafeVault.Data;
using SafeVault.DTOs;
using SafeVault.Models;

namespace SafeVault.Services;

/// <summary>
/// Handles user registration, login, and role management.
/// Security highlights:
///   • Passwords hashed with BCrypt (work factor 12) — never stored plain.
///   • Username/email uniqueness enforced at DB and service layers.
///   • Parameterised EF Core queries prevent SQL injection (Activity 1).
///   • Role elevation restricted to Admin callers (Activity 2 RBAC).
/// </summary>
public interface IAuthService
{
    Task<(bool Success, string Error, User? User)> RegisterAsync(RegisterRequest request);
    Task<(bool Success, string Error, User? User)> LoginAsync(LoginRequest request);
    Task<(bool Success, string Error)> UpdateUserRoleAsync(int targetUserId, UserRole newRole, int requestingUserId);
    Task<IEnumerable<User>> GetAllUsersAsync();
}

public class AuthService : IAuthService
{
    private readonly AppDbContext          _db;
    private readonly IInputValidationService _validator;

    public AuthService(AppDbContext db, IInputValidationService validator)
    {
        _db        = db;
        _validator = validator;
    }

    // ── Registration ─────────────────────────────────────────────────────────

    public async Task<(bool Success, string Error, User? User)> RegisterAsync(
        RegisterRequest request)
    {
        // 1. Server-side validation (belt-and-suspenders beyond DataAnnotations)
        if (!_validator.IsValidUsername(request.Username))
            return (false, "Invalid username format.", null);

        if (!_validator.IsValidEmail(request.Email))
            return (false, "Invalid email address.", null);

        if (!_validator.IsValidPassword(request.Password))
            return (false,
                "Password must be ≥ 8 characters with upper, lower, digit, and special character.",
                null);

        // 2. Reject input that looks like SQL injection (heuristic extra layer)
        if (_validator.ContainsSqlInjectionPatterns(request.Username) ||
            _validator.ContainsSqlInjectionPatterns(request.Email))
            return (false, "Input contains invalid characters.", null);

        // 3. EF Core parameterised query — safe from SQL injection by design
        bool userExists = await _db.Users
            .AnyAsync(u => u.Username == request.Username.Trim() ||
                           u.Email    == request.Email.Trim());

        if (userExists)
            return (false, "Username or email already registered.", null);

        // 4. Hash the password with BCrypt (work factor 12)
        var user = new User
        {
            Username     = request.Username.Trim(),
            Email        = request.Email.Trim().ToLowerInvariant(),
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.Password, workFactor: 12),
            Role         = request.Role,
            CreatedAt    = DateTime.UtcNow,
            IsActive     = true
        };

        _db.Users.Add(user);
        await _db.SaveChangesAsync();

        return (true, string.Empty, user);
    }

    // ── Login ─────────────────────────────────────────────────────────────────

    public async Task<(bool Success, string Error, User? User)> LoginAsync(
        LoginRequest request)
    {
        if (!_validator.IsValidUsername(request.Username))
            return (false, "Invalid credentials.", null);

        // Parameterised EF Core query — no string concatenation
        var user = await _db.Users
            .FirstOrDefaultAsync(u => u.Username == request.Username.Trim() &&
                                      u.IsActive  == true);

        if (user is null)
            // Generic message — don't reveal whether user exists (enumeration attack)
            return (false, "Invalid credentials.", null);

        // Constant-time BCrypt verify — prevents timing attacks
        bool passwordValid = BCrypt.Net.BCrypt.Verify(request.Password, user.PasswordHash);
        if (!passwordValid)
            return (false, "Invalid credentials.", null);

        return (true, string.Empty, user);
    }

    // ── Role Management (Admin only) ─────────────────────────────────────────

    public async Task<(bool Success, string Error)> UpdateUserRoleAsync(
        int targetUserId, UserRole newRole, int requestingUserId)
    {
        // Prevent admins from demoting themselves
        if (targetUserId == requestingUserId)
            return (false, "You cannot change your own role.");

        var requestingUser = await _db.Users.FindAsync(requestingUserId);
        if (requestingUser?.Role != UserRole.Admin)
            return (false, "Insufficient permissions.");

        var target = await _db.Users.FindAsync(targetUserId);
        if (target is null)
            return (false, "User not found.");

        target.Role = newRole;
        await _db.SaveChangesAsync();

        return (true, string.Empty);
    }

    public async Task<IEnumerable<User>> GetAllUsersAsync()
        => await _db.Users.OrderBy(u => u.Id).ToListAsync();
}
