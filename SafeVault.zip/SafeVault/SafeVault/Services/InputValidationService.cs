using System.Text.RegularExpressions;
using Ganss.Xss;

namespace SafeVault.Services;

/// <summary>
/// Centralised input validation and sanitisation helpers.
/// Satisfies Activity 1 requirements:
///   • Input validation (whitelist-based patterns)
///   • XSS sanitisation via HtmlSanitizer (Activity 3 fix)
/// </summary>
public interface IInputValidationService
{
    bool IsValidUsername(string username);
    bool IsValidEmail(string email);
    bool IsValidPassword(string password);
    string SanitizeHtml(string input);
    bool ContainsSqlInjectionPatterns(string input);
}

public class InputValidationService : IInputValidationService
{
    private readonly HtmlSanitizer _sanitizer;

    // Whitelist: only safe characters allowed in usernames
    private static readonly Regex UsernameRegex =
        new(@"^[a-zA-Z0-9_\-\.]{3,50}$", RegexOptions.Compiled);

    private static readonly Regex EmailRegex =
        new(@"^[^@\s]+@[^@\s]+\.[^@\s]+$",
            RegexOptions.Compiled | RegexOptions.IgnoreCase);

    // Password: min 8 chars, must contain upper, lower, digit, special char
    private static readonly Regex PasswordRegex =
        new(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,100}$",
            RegexOptions.Compiled);

    // Common SQL injection keywords — used as an extra heuristic warning
    // NOTE: The real defence is parameterised queries, not this check alone.
    private static readonly string[] SqlKeywords =
    [
        "'; ", "--", "/*", "*/", "xp_", "exec(", "execute(",
        "drop ", "insert ", "delete ", "update ", "select ",
        "union ", "or 1=1", "or '1'='1"
    ];

    public InputValidationService()
    {
        _sanitizer = new HtmlSanitizer();
        // Only allow a safe subset of HTML tags (for rich-text vault content)
        _sanitizer.AllowedTags.Clear();
        _sanitizer.AllowedTags.Add("b");
        _sanitizer.AllowedTags.Add("i");
        _sanitizer.AllowedTags.Add("u");
        _sanitizer.AllowedTags.Add("p");
        _sanitizer.AllowedTags.Add("br");
    }

    /// <summary>Returns true if the username matches the safe whitelist pattern.</summary>
    public bool IsValidUsername(string username)
    {
        if (string.IsNullOrWhiteSpace(username)) return false;
        return UsernameRegex.IsMatch(username.Trim());
    }

    /// <summary>Returns true if the email is syntactically valid.</summary>
    public bool IsValidEmail(string email)
    {
        if (string.IsNullOrWhiteSpace(email)) return false;
        return EmailRegex.IsMatch(email.Trim()) && email.Length <= 200;
    }

    /// <summary>
    /// Returns true if the password meets complexity requirements.
    /// At least 8 characters; uppercase, lowercase, digit, special character.
    /// </summary>
    public bool IsValidPassword(string password)
    {
        if (string.IsNullOrWhiteSpace(password)) return false;
        return PasswordRegex.IsMatch(password);
    }

    /// <summary>
    /// Strips dangerous HTML / scripts from user-supplied rich text.
    /// Prevents XSS — Activity 3 vulnerability fix.
    /// </summary>
    public string SanitizeHtml(string input)
    {
        if (string.IsNullOrEmpty(input)) return string.Empty;
        return _sanitizer.Sanitize(input);
    }

    /// <summary>
    /// Heuristic check for obvious SQL injection patterns.
    /// This is a secondary defence; parameterised queries are the primary fix.
    /// </summary>
    public bool ContainsSqlInjectionPatterns(string input)
    {
        if (string.IsNullOrEmpty(input)) return false;
        var lower = input.ToLowerInvariant();
        return SqlKeywords.Any(k => lower.Contains(k));
    }
}
