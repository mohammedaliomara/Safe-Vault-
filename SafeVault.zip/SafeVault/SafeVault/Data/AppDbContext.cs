using Microsoft.EntityFrameworkCore;
using SafeVault.Models;

namespace SafeVault.Data;

/// <summary>
/// Application database context.
/// ALL queries that accept user input use EF Core parameterized queries or
/// raw SQL with SqlParameter — never string concatenation.
/// This directly addresses Activity 1 (SQL injection prevention).
/// </summary>
public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<VaultItem> VaultItems => Set<VaultItem>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // ── User ────────────────────────────────────────────────────────────
        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(u => u.Id);

            entity.HasIndex(u => u.Username)
                  .IsUnique();                // Enforce uniqueness at DB level

            entity.HasIndex(u => u.Email)
                  .IsUnique();

            entity.Property(u => u.Username)
                  .IsRequired()
                  .HasMaxLength(50);

            entity.Property(u => u.PasswordHash)
                  .IsRequired()
                  .HasMaxLength(256);

            entity.Property(u => u.Email)
                  .IsRequired()
                  .HasMaxLength(200);

            entity.Property(u => u.Role)
                  .HasConversion<string>();   // Store as readable string
        });

        // ── VaultItem ───────────────────────────────────────────────────────
        modelBuilder.Entity<VaultItem>(entity =>
        {
            entity.HasKey(v => v.Id);

            entity.Property(v => v.Title)
                  .IsRequired()
                  .HasMaxLength(200);

            entity.Property(v => v.Content)
                  .IsRequired()
                  .HasMaxLength(10_000);

            entity.HasOne(v => v.Owner)
                  .WithMany()
                  .HasForeignKey(v => v.OwnerId)
                  .OnDelete(DeleteBehavior.Cascade);
        });

        // ── Seed data ───────────────────────────────────────────────────────
        // Admin user seeded for demo purposes.
        // Password: Admin@12345  (BCrypt hash generated offline)
        modelBuilder.Entity<User>().HasData(new User
        {
            Id           = 1,
            Username     = "admin",
            Email        = "admin@safevault.local",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin@12345"),
            Role         = UserRole.Admin,
            CreatedAt    = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc),
            IsActive     = true
        });
    }
}
