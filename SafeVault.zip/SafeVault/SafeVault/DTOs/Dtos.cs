using System.ComponentModel.DataAnnotations;
using SafeVault.Models;

namespace SafeVault.DTOs;

// ──────────────────────────────────────────────────────────────────────────────
// Auth DTOs
// ──────────────────────────────────────────────────────────────────────────────

/// <summary>
/// Login request.  Data annotations enforce server-side input validation
/// (Activity 1 – input validation requirement).
/// </summary>
public class LoginRequest
{
    [Required(ErrorMessage = "Username is required.")]
    [StringLength(50, MinimumLength = 3,
        ErrorMessage = "Username must be between 3 and 50 characters.")]
    [RegularExpression(@"^[a-zA-Z0-9_\-\.]+$",
        ErrorMessage = "Username may only contain letters, digits, underscores, hyphens, and dots.")]
    public string Username { get; set; } = string.Empty;

    [Required(ErrorMessage = "Password is required.")]
    [StringLength(100, MinimumLength = 8,
        ErrorMessage = "Password must be at least 8 characters.")]
    public string Password { get; set; } = string.Empty;
}

/// <summary>Register request — extends login with email and role.</summary>
public class RegisterRequest
{
    [Required]
    [StringLength(50, MinimumLength = 3)]
    [RegularExpression(@"^[a-zA-Z0-9_\-\.]+$",
        ErrorMessage = "Username may only contain letters, digits, underscores, hyphens, and dots.")]
    public string Username { get; set; } = string.Empty;

    [Required]
    [StringLength(100, MinimumLength = 8)]
    [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).+$",
        ErrorMessage = "Password must contain uppercase, lowercase, digit, and special character.")]
    public string Password { get; set; } = string.Empty;

    [Required]
    [EmailAddress(ErrorMessage = "Invalid email address format.")]
    [StringLength(200)]
    public string Email { get; set; } = string.Empty;

    // New users are always Viewer by default; only Admins can elevate roles
    public UserRole Role { get; set; } = UserRole.Viewer;
}

public class AuthResponse
{
    public string Token { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public DateTime ExpiresAt { get; set; }
}

// ──────────────────────────────────────────────────────────────────────────────
// Vault DTOs
// ──────────────────────────────────────────────────────────────────────────────

public class CreateVaultItemRequest
{
    [Required]
    [StringLength(200, MinimumLength = 1, ErrorMessage = "Title must be 1–200 characters.")]
    public string Title { get; set; } = string.Empty;

    [Required]
    [StringLength(10000, ErrorMessage = "Content cannot exceed 10 000 characters.")]
    public string Content { get; set; } = string.Empty;
}

public class VaultItemResponse
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;
    public string OwnerUsername { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}

// ──────────────────────────────────────────────────────────────────────────────
// Admin DTOs
// ──────────────────────────────────────────────────────────────────────────────

public class UpdateRoleRequest
{
    [Required]
    public int UserId { get; set; }

    [Required]
    [EnumDataType(typeof(UserRole))]
    public UserRole NewRole { get; set; }
}
