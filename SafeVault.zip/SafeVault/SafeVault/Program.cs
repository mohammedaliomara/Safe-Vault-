using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using SafeVault.Data;
using SafeVault.Middleware;
using SafeVault.Services;

var builder = WebApplication.CreateBuilder(args);

// ── 1. Database ──────────────────────────────────────────────────────────────
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection")));

// ── 2. DI – Application Services ────────────────────────────────────────────
builder.Services.AddScoped<IInputValidationService, InputValidationService>();
builder.Services.AddScoped<IAuthService,            AuthService>();
builder.Services.AddScoped<ITokenService,           TokenService>();
builder.Services.AddScoped<IVaultService,           VaultService>();

// ── 3. JWT Authentication (Activity 2) ──────────────────────────────────────
var jwtKey = builder.Configuration["Jwt:Key"]!;
builder.Services
    .AddAuthentication(options =>
    {
        options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultChallengeScheme    = JwtBearerDefaults.AuthenticationScheme;
    })
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey         = new SymmetricSecurityKey(
                                           Encoding.UTF8.GetBytes(jwtKey)),
            ValidateIssuer           = true,
            ValidIssuer              = builder.Configuration["Jwt:Issuer"],
            ValidateAudience         = true,
            ValidAudience            = builder.Configuration["Jwt:Audience"],
            ClockSkew                = TimeSpan.Zero
        };
    });

// ── 4. RBAC Authorisation Policies (Activity 2) ──────────────────────────────
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AdminOnly",   policy => policy.RequireRole("Admin"));
    options.AddPolicy("EditorPlus",  policy => policy.RequireRole("Editor", "Admin"));
    options.AddPolicy("AnyRole",     policy => policy.RequireRole("Viewer", "Editor", "Admin"));
});

// ── 5. Controllers + Swagger ─────────────────────────────────────────────────
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title   = "SafeVault API",
        Version = "v1",
        Description =
            "Secure vault API demonstrating input validation, SQL injection prevention, " +
            "JWT authentication, and role-based access control."
    });

    // Enable the Authorize button in Swagger UI
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "JWT token — paste the token from /api/auth/login",
        Name        = "Authorization",
        In          = ParameterLocation.Header,
        Type        = SecuritySchemeType.Http,
        Scheme      = "bearer"
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                    { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
            },
            Array.Empty<string>()
        }
    });
});

// ── 6. Build the app ─────────────────────────────────────────────────────────
var app = builder.Build();

// ── 7. Ensure DB is created and migrations applied ───────────────────────────
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();   // Creates SQLite file + seeds admin user
}

// ── 8. Middleware pipeline ────────────────────────────────────────────────────
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "SafeVault v1"));
}

app.UseHttpsRedirection();

// Anti-XSS middleware (Activity 3) — runs before controllers
app.UseMiddleware<AntiXssMiddleware>();

app.UseAuthentication();   // Must come before UseAuthorization
app.UseAuthorization();

app.MapControllers();

app.Run();

// Make Program partial so the test project can reference it
public partial class Program { }
