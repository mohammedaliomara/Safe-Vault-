using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SafeVault.DTOs;
using SafeVault.Models;
using SafeVault.Services;

namespace SafeVault.Controllers;

/// <summary>
/// CRUD endpoints for vault items.
/// Every endpoint requires a valid JWT ([Authorize]).
/// Specific endpoints further restrict access by Role.
/// Activity 2 – RBAC implementation.
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Authorize]   // All endpoints require a valid JWT
public class VaultController : ControllerBase
{
    private readonly IVaultService _vault;

    public VaultController(IVaultService vault)
    {
        _vault = vault;
    }

    // ── Helper ──────────────────────────────────────────────────────────────

    private int    CurrentUserId   => int.Parse(User.FindFirstValue("userId")!);
    private UserRole CurrentRole   =>
        Enum.Parse<UserRole>(User.FindFirstValue(ClaimTypes.Role)!);

    // ── Endpoints ───────────────────────────────────────────────────────────

    /// <summary>
    /// Create a vault item. Requires Editor or Admin role.
    /// Input HTML is sanitised inside VaultService (XSS prevention).
    /// </summary>
    [HttpPost]
    [Authorize(Roles = "Editor,Admin")]
    [ProducesResponseType(typeof(VaultItemResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create([FromBody] CreateVaultItemRequest request)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);

        var item = await _vault.CreateAsync(request, CurrentUserId);
        return CreatedAtAction(nameof(GetById), new { id = item.Id }, item);
    }

    /// <summary>
    /// List vault items.
    /// Admins see all items; Viewers/Editors see only their own.
    /// </summary>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<VaultItemResponse>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll()
    {
        var items = await _vault.GetAllAsync(CurrentUserId, CurrentRole);
        return Ok(items);
    }

    /// <summary>
    /// Get a single vault item by ID.
    /// Returns 404 if the caller does not have access (no information leakage).
    /// </summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(VaultItemResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(int id)
    {
        var item = await _vault.GetByIdAsync(id, CurrentUserId, CurrentRole);
        return item is null ? NotFound() : Ok(item);
    }

    /// <summary>
    /// Delete a vault item. Admin can delete any; owner can delete their own.
    /// </summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(int id)
    {
        var deleted = await _vault.DeleteAsync(id, CurrentUserId, CurrentRole);
        return deleted ? NoContent() : NotFound();
    }
}
