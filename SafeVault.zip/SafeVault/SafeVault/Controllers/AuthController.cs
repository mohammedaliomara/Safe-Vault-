using Microsoft.AspNetCore.Mvc;
using SafeVault.DTOs;
using SafeVault.Services;

namespace SafeVault.Controllers;

/// <summary>
/// Handles user registration and login.
/// Returns JWT tokens used for all subsequent authenticated requests.
/// Activity 2 – Authentication endpoints.
/// </summary>
[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IAuthService  _auth;
    private readonly ITokenService _token;

    public AuthController(IAuthService auth, ITokenService token)
    {
        _auth  = auth;
        _token = token;
    }

    /// <summary>
    /// Register a new user account.
    /// Input is validated via DataAnnotations and the InputValidationService.
    /// </summary>
    [HttpPost("register")]
    [ProducesResponseType(typeof(AuthResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Register([FromBody] RegisterRequest request)
    {
        // ModelState validates DataAnnotations on RegisterRequest
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var (success, error, user) = await _auth.RegisterAsync(request);
        if (!success)
            return BadRequest(new { error });

        var jwt = _token.GenerateToken(user!);
        return CreatedAtAction(nameof(Register), new AuthResponse
        {
            Token     = jwt,
            Username  = user!.Username,
            Role      = user.Role.ToString(),
            ExpiresAt = DateTime.UtcNow.AddHours(8)
        });
    }

    /// <summary>
    /// Authenticate a user and receive a JWT token.
    /// </summary>
    [HttpPost("login")]
    [ProducesResponseType(typeof(AuthResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var (success, error, user) = await _auth.LoginAsync(request);
        if (!success)
            // 401 with a generic message — don't reveal whether the user exists
            return Unauthorized(new { error });

        var jwt = _token.GenerateToken(user!);
        return Ok(new AuthResponse
        {
            Token     = jwt,
            Username  = user!.Username,
            Role      = user.Role.ToString(),
            ExpiresAt = DateTime.UtcNow.AddHours(8)
        });
    }
}
