using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SafeVault.DTOs;
using SafeVault.Services;

namespace SafeVault.Controllers;

/// <summary>
/// Admin-only endpoints for user management.
/// Activity 2 – Role-Based Access Control (RBAC): only users with Role == Admin
/// may call any action in this controller.
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "Admin")]   // Entire controller restricted to Admins
public class AdminController : ControllerBase
{
    private readonly IAuthService _auth;

    public AdminController(IAuthService auth)
    {
        _auth = auth;
    }

    private int CurrentUserId =>
        int.Parse(User.FindFirstValue("userId")!);

    /// <summary>List all registered users (Admin only).</summary>
    [HttpGet("users")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAllUsers()
    {
        var users = await _auth.GetAllUsersAsync();
        return Ok(users.Select(u => new
        {
            u.Id,
            u.Username,
            u.Email,
            Role      = u.Role.ToString(),
            u.IsActive,
            u.CreatedAt
        }));
    }

    /// <summary>Change a user's role (Admin only). Admin cannot change their own role.</summary>
    [HttpPut("users/role")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> UpdateRole([FromBody] UpdateRoleRequest request)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);

        var (success, error) =
            await _auth.UpdateUserRoleAsync(request.UserId, request.NewRole, CurrentUserId);

        return success
            ? Ok(new { message = $"Role updated to {request.NewRole}." })
            : BadRequest(new { error });
    }
}
